{
int i, j = 0;

auto C0 = new TCanvas();

for(i;i<=100; i++){
	LeftThyVsRightThy0Tracks->SetBinContent(i,51,0);
	}
LeftThyVsRightThy0Tracks->Draw("COLZ");
for(j;j<=100; j++){
	LeftThyVsRightThy0Tracks->SetBinContent(51,j,0);
	}
LeftThyVsRightThy0Tracks->Draw("COLZ");	

int k, l = 0;

auto C1 = new TCanvas();

for(k;k<=100; k++){
	LeftThyVsRightThy1Tracks->SetBinContent(k,51,0);
	}
LeftThyVsRightThy1Tracks->Draw("COLZ");
for(l;l<=100; l++){
	LeftThyVsRightThy1Tracks->SetBinContent(51,l,0);
	}
LeftThyVsRightThy1Tracks->Draw("COLZ");	

int m, n = 0;

auto C2 = new TCanvas();

for(m;m<=100; m++){
	LeftThyVsRightThy2Tracks->SetBinContent(m,51,0);
	}
LeftThyVsRightThy2Tracks->Draw("COLZ");
for(n;n<=100; n++){
	LeftThyVsRightThy2Tracks->SetBinContent(51,n,0);
	}
LeftThyVsRightThy2Tracks->Draw("COLZ");	


}


